abstract class DeleteTodoUseCase {
  Future<void> execute(final int id);
}
