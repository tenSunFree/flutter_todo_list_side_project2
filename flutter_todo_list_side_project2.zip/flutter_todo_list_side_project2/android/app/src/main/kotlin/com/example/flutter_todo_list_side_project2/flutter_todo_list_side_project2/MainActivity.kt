package com.example.flutter_todo_list_side_project2.flutter_todo_list_side_project2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
